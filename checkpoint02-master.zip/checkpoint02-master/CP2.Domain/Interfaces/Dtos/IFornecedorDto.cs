﻿namespace CP2.Domain.Interfaces.Dtos
{
    public interface IFornecedorDto
    {

        void Validate();
    }
}
