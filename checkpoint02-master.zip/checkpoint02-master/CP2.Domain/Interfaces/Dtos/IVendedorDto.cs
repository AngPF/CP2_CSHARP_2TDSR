﻿namespace CP2.Domain.Interfaces.Dtos
{
    public interface IVendedorDto
    {

        void Validate();
    }
}
