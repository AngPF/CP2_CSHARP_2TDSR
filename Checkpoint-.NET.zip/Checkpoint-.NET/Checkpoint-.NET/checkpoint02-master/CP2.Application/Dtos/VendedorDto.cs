﻿using CP2.Domain.Interfaces.Dtos;
using FluentValidation;
using System;

namespace CP2.Application.Dtos
{
    public class VendedorDto : IVendedorDto
    {

        public string Nome { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Telefone { get; set; } = string.Empty;

        public DateTime DataNascimento { get; set; } 

        public string Endereco { get; set; } = string.Empty;

        public DateTime DataContratacao { get; set; } 

        public decimal ComissaoPercentual { get; set; } 

        public decimal MetaMensal { get; set; }  

        public void Validate()
        {
            var validateResult = new VendedorDtoValidation().Validate(this);

            if (!validateResult.IsValid)
                throw new Exception(string.Join(" e ", validateResult.Errors.Select(x => x.ErrorMessage)));
        }
    }

    internal class VendedorDtoValidation : AbstractValidator<VendedorDto>
    {
        public VendedorDtoValidation()
        {
            RuleFor(x => x.Nome)
                .NotEmpty().WithMessage("O nome do vendedor é obrigatório.")
                .Length(2, 100).WithMessage("O nome do vendedor deve ter entre 2 e 100 caracteres.");

            RuleFor(x => x.Email)
                .EmailAddress().WithMessage("O email do vendedor deve ser um endereço de email válido.")
                .When(x => !string.IsNullOrEmpty(x.Email));

            RuleFor(x => x.Telefone)
                .NotEmpty().WithMessage("O telefone do vendedor é obrigatório")
                .When(x => !string.IsNullOrEmpty(x.Telefone));

            RuleFor(x => x.DataNascimento)
                .LessThan(DateTime.Now).WithMessage("A data de nascimento deve ser anterior a data atual.");

            RuleFor(x => x.DataContratacao)
                .LessThan(DateTime.Now).WithMessage("A data de contratação deve ser anterior a data atual.");
        }
    }
}
