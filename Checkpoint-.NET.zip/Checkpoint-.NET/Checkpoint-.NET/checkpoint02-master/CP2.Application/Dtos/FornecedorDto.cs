﻿using CP2.Domain.Interfaces.Dtos;
using FluentValidation;
using System;

namespace CP2.Application.Dtos
{
    public class FornecedorDto : IFornecedorDto
    {
        public string Nome { get; set; } = string.Empty;

        public string CNPJ { get; set; } = string.Empty;

        public string Endereco { get; set; } = string.Empty;

        public string Telefone { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public void Validate()
        {
            var validateResult = new FornecedorDtoValidation().Validate(this);

            if (!validateResult.IsValid)
                throw new Exception(string.Join(" e ", validateResult.Errors.Select(x => x.ErrorMessage)));
        }
    }

    internal class FornecedorDtoValidation : AbstractValidator<FornecedorDto>
    {
        public FornecedorDtoValidation()
        {
            RuleFor(x => x.Nome)
                .NotEmpty().WithMessage("O nome do fornecedor é obrigatório.")
                .Length(2, 100).WithMessage("O nome do fornecedor deve ter entre 2 e 100 caracteres.");

            RuleFor(x => x.CNPJ)
                .NotEmpty().WithMessage("O CNPJ do fornecedor é obrigatório.")
                .Length(14).WithMessage("O CNPJ deve ter 14 caracteres.");

            RuleFor(x => x.Email)
                .EmailAddress().WithMessage("O email do fornecedor deve ser um endereço de email válido.")
                .When(x => !string.IsNullOrEmpty(x.Email)); 

            RuleFor(x => x.Telefone)
                .NotEmpty().WithMessage("O telefone é obrigatório")
                .When(x => !string.IsNullOrEmpty(x.Telefone)); 
        }
    }
}
