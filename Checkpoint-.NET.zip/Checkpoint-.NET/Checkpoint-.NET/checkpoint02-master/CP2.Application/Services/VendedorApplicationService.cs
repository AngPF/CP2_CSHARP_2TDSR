﻿using CP2.Domain.Entities;
using CP2.Domain.Interfaces;
using CP2.Domain.Interfaces.Dtos;
using System.Collections.Generic;

namespace CP2.Application.Services
{
    public class VendedorApplicationService : IVendedorApplicationService
    {
        private readonly IVendedorRepository _repository;

        public VendedorApplicationService(IVendedorRepository repository)
        {
            _repository = repository;
        }

        public VendedorEntity? DeletarDadosVendedor(int id)
        {
            return _repository.DeletarDados(id);
        }

        public IEnumerable<VendedorEntity> ObterTodosVendedores()
        {
            return _repository.ObterTodos();
        }

        public VendedorEntity? ObterVendedorPorId(int id)
        {
            return _repository.ObterPorId(id);
        }

        public VendedorEntity? SalvarDadosVendedor(IVendedorDto dto)
        {
            dto.Validate();

            var vendedor = new VendedorEntity
            {
                Nome = dto.Nome,
                Email = dto.Email,
                Telefone = dto.Telefone,
                DataNascimento = dto.DataNascimento,
                Endereco = dto.Endereco,
                DataContratacao = dto.DataContratacao,
                ComissaoPercentual = dto.ComissaoPercentual,
                MetaMensal = dto.MetaMensal
            };

            return _repository.SalvarDados(vendedor);
        }

        public VendedorEntity? EditarDadosVendedor(int id, IVendedorDto dto)
        {
            dto.Validate();

            var vendedorExistente = _repository.ObterPorId(id);
            if (vendedorExistente == null)
            {
                return null; 
            }

            vendedorExistente.Nome = dto.Nome;
            vendedorExistente.Email = dto.Email;
            vendedorExistente.Telefone = dto.Telefone;
            vendedorExistente.DataNascimento = dto.DataNascimento;
            vendedorExistente.Endereco = dto.Endereco;
            vendedorExistente.DataContratacao = dto.DataContratacao;
            vendedorExistente.ComissaoPercentual = dto.ComissaoPercentual;
            vendedorExistente.MetaMensal = dto.MetaMensal;

            return _repository.EditarDados(vendedorExistente);
        }
    }
}
