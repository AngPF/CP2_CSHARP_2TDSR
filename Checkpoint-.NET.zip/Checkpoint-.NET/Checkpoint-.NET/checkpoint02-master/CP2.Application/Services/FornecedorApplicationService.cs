﻿using CP2.Domain.Entities;
using CP2.Domain.Interfaces;
using CP2.Domain.Interfaces.Dtos;
using System.Collections.Generic;

namespace CP2.Application.Services
{
    public class FornecedorApplicationService : IFornecedorApplicationService
    {
        private readonly IFornecedorRepository _repository;

        public FornecedorApplicationService(IFornecedorRepository repository)
        {
            _repository = repository;
        }

        public FornecedorEntity? DeletarDadosFornecedor(int id)
        {
            return _repository.DeletarDados(id);
        }

        public FornecedorEntity? ObterFornecedorPorId(int id)
        {
            return _repository.ObterPorId(id);
        }

        public IEnumerable<FornecedorEntity> ObterTodosFornecedores()
        {
            return _repository.ObterTodos();
        }

        public FornecedorEntity? SalvarDadosFornecedor(IFornecedorDto dto)
        {
            dto.Validate();

            var fornecedor = new FornecedorEntity
            {
                Nome = dto.Nome,
                CNPJ = dto.CNPJ,
                Endereco = dto.Endereco,
                Telefone = dto.Telefone,
                Email = dto.Email 
            };

            return _repository.SalvarDados(fornecedor);
        }

        public FornecedorEntity? EditarDadosFornecedor(int id, IFornecedorDto dto)
        {
            dto.Validate();

            var fornecedorExistente = _repository.ObterPorId(id);
            if (fornecedorExistente == null)
            {
                return null; 
            }

            fornecedorExistente.Nome = dto.Nome;
            fornecedorExistente.CNPJ = dto.CNPJ; 
            fornecedorExistente.Endereco = dto.Endereco;
            fornecedorExistente.Telefone = dto.Telefone;
            fornecedorExistente.Email = dto.Email; 

            return _repository.EditarDados(fornecedorExistente);
        }
    }
}
