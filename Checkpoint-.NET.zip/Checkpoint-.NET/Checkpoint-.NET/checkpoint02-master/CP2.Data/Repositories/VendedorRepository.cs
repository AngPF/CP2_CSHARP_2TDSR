﻿using CP2.Data.AppData;
using CP2.Domain.Entities;
using CP2.Domain.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace CP2.Data.Repositories
{
    public class VendedorRepository : IVendedorRepository
    {
        private readonly ApplicationContext _context;

        public VendedorRepository(ApplicationContext context)
        {
            _context = context;
        }

        public VendedorEntity? SalvarDados(VendedorEntity vendedor)
        {
            _context.Vendedor.Add(vendedor);
            _context.SaveChanges();
            return vendedor;
        }

        public VendedorEntity? ObterPorId(int id)
        {
            var vendedor = _context.Vendedor.Find(id);

            if (vendedor is not null)
            {
                return vendedor;
            }

            return null;
        }

        public IEnumerable<VendedorEntity> ObterTodos()
        {
            var vendedores = _context.Vendedor.ToList();

            return vendedores;
        }

        public VendedorEntity? EditarDados(VendedorEntity vendedor)
        {
            var entity = _context.Vendedor.Find(vendedor.Id);

            if (vendedor is not null)
            {
                vendedor.Nome = vendedor.Nome;
                vendedor.Email = vendedor.Email;
                vendedor.Telefone = vendedor.Telefone;
                vendedor.DataNascimento = vendedor.DataNascimento;
                vendedor.Endereco = vendedor.Endereco;
                vendedor.DataContratacao = vendedor.DataContratacao;
                vendedor.ComissaoPercentual = vendedor.ComissaoPercentual;
                vendedor.MetaMensal = vendedor.MetaMensal;
                vendedor.CriadoEm = vendedor.CriadoEm; 

                _context.Vendedor.Update(vendedor);
                _context.SaveChanges();

                return entity;
            }

            return null;
        }


        public VendedorEntity? DeletarDados(int id)
        {
            var entity = _context.Vendedor.FirstOrDefault(v => v.Id == id);

            if (entity is not null)
            {
                _context.Vendedor.Remove(entity);
                _context.SaveChanges();

                return entity;
            }

            return null;
        }
    }
}
