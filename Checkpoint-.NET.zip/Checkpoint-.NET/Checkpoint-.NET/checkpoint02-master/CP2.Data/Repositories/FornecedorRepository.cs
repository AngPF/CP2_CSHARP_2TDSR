﻿using CP2.Data.AppData;
using CP2.Domain.Entities;
using CP2.Domain.Interfaces;
using System.Collections.Generic;
using System.Linq;

namespace CP2.Data.Repositories
{
    public class FornecedorRepository : IFornecedorRepository
    {
        private readonly ApplicationContext _context;

        public FornecedorRepository(ApplicationContext context)
        {
            _context = context;
        }

        public FornecedorEntity? SalvarDados(FornecedorEntity fornecedor)
        {
            _context.Fornecedor.Add(fornecedor);
            _context.SaveChanges();
            return fornecedor;
        }

        public FornecedorEntity? ObterPorId(int id)
        {
            var fornecedor = _context.Fornecedor.Find(id);

            if (fornecedor is not null)
            {
                return fornecedor;
            }

            return null;
        }

        public IEnumerable<FornecedorEntity> ObterTodos()
        {
            var fornecedores = _context.Fornecedor.ToList();

            return fornecedores;
        }

        public FornecedorEntity? EditarDados(FornecedorEntity fornecedor)
        {
            var entity = _context.Fornecedor.Find(fornecedor.Id);

            if (fornecedor is not null)
            {
                fornecedor.Nome = fornecedor.Nome;
                fornecedor.CNPJ = fornecedor.CNPJ;
                fornecedor.Endereco = fornecedor.Endereco;
                fornecedor.Telefone = fornecedor.Telefone;
                fornecedor.Email = fornecedor.Email;

                _context.Fornecedor.Update(fornecedor);
                _context.SaveChanges();

                return entity;
            }

            return null;
        }

        public FornecedorEntity? DeletarDados(int id)
        {
            var entity = _context.Fornecedor.FirstOrDefault(v => v.Id == id);

            if (entity is not null)
            {
                _context.Fornecedor.Remove(entity);
                _context.SaveChanges();

                return entity;
            }

            return null;
        }
    }
}
